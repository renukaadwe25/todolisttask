import React from 'react';
import CardTodo from './CardTodo';

function TodoList({ TaskList, TaskCompleted ,OnDelete}) {
  return (
    <div>
      {TaskList.map((item) => (
        <div key={item.id}>
          <CardTodo item={item} TaskCompleted={TaskCompleted} OnDelete={OnDelete} />
        </div>
      ))}
    </div>
  );
}

export default TodoList;
