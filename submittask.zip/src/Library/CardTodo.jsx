import React, { useState } from 'react';
import { Typography, Card, Button, Box, Checkbox , Grid} from '@mui/material';
import DeleteIcon from '@mui/icons-material/Delete';
function CardTodo({ item, TaskCompleted, OnDelete }) {
  const [check, setCheck] = useState(false)
  const onCheck = () => {
    setCheck(!check);
    TaskCompleted(item.id);
  };

  return (
    <div>
      <Card sx={{ backgroundColor: '#bdbdbd'}} component={Box} mx={10} my={3} p={2}>
        <Grid container >
          <Grid item sm={1}>
            <Checkbox
              checked={check}
              onChange={onCheck} />
          </Grid>
          <Grid item sm={8}>
            <Typography>{item.task}</Typography>
          </Grid>
          <Grid item sm={3}>
            <Button onClick={() => OnDelete(item.id)} variant='contained' color={'error'} sx={{}} endIcon={<DeleteIcon />} >Delete</Button>
          </Grid>
        </Grid>
      </Card>
    </div>
  );
}

export default CardTodo;
