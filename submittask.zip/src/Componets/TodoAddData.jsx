import { Card, TextField, Typography, Grid, Button, Checkbox } from '@mui/material'
import React, { useState } from 'react'
import AddCircleIcon from '@mui/icons-material/AddCircle';

function TodoAddData({ AddTask }) {
  const [task, setTask] = useState('')


  const onAdd = () => {
    if (task == '') {
      alert('Please add a task')
    } else {
      setTask('')
      AddTask({ task })
    }

  }

  return (
    <Grid container>
      <Grid item xs={3}></Grid>
      <Grid item xs={6}>
        <Card sx={{ padding: "10px", border:"1px solid lightblue"}}>
          <TextField value={task} onChange={(e) => setTask(e.target.value)} fullWidth placeholder='Add Task'></TextField><br></br><br></br>
          <Button onClick={onAdd} variant='contained' color={'success'} endIcon={<AddCircleIcon />}>Add</Button>
        </Card>
      </Grid>
    </Grid>

  )
}

export default TodoAddData