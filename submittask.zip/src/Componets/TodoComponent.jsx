import React, { useState, useEffect } from 'react'
import TodoList from '../Library/TodoList'
import axios from 'axios';
import { Container, Typography ,Box ,Card} from '@mui/material';
import TodoAddData from './TodoAddData';

function TodoComponent() {
  const [taskList, setTaskList] = useState([])

  useEffect(() => {
       axios.get("http://localhost:30001/todos")
       .then(res => setTaskList(res.data))
  }, []);



const AddTask = (value) => {
  axios.post('http://localhost:30001/todos', value)
    .then(res => {
      setTaskList(task => [...task, res.data]);
    })
  };


const TaskCompleted = (taskId) => {
  const completeTasks = taskList.map((task) =>
    task.id === taskId ? { ...task, completed: !task.completed } : task
  );
    setTaskList(completeTasks);
   
    axios.patch(`http://localhost:30001/todos/${taskId}`, {
    completed: completeTasks.find((task) => task.id === taskId).completed,
  })
};

const onDeleteTask = (taskId) => {
  axios.delete(`http://localhost:30001/todos/${taskId}`)
    .then((res) => {
     const DeleteTasks = taskList.filter((task) => task.id !== taskId);
     setTaskList(DeleteTasks);
    })
  };

return (
    <Container>
      <Card component={Box} m={5} >
      <Typography variant='h3' sx={{textAlign:"center"}} component={Box} m={3}>ToDO List</Typography>
      <TodoAddData AddTask={AddTask}/>
      <TodoList TaskList={taskList} TaskCompleted ={TaskCompleted } OnDelete={onDeleteTask}/>
      </Card>
  
    </Container>
  )
}

export default TodoComponent